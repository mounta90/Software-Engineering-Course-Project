from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
import webbrowser
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
import sqlite3
import re

Window.size = 300, 600 # Phone size



class WindowManager(ScreenManager):
	pass

class RegistrationLogin_Window(Screen):
	pass

class Pages_Window(Screen):
	pass



class MainApp(MDApp):

	def build(self):

		# BEGINNING OF database creation

		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		cursor.execute("""
			CREATE TABLE IF NOT EXISTS users(
				username TEXT,
				password TEXT,
				points INTEGER
			)
		""")

		connection.commit()
		connection.close()

		# ENDING OF database creation

		return Builder.load_file('mainApp.kv')
	

	def registerUser(self, enteredUsername_ID, enteredPassword_ID, reEnteredPassword_ID):

		# Check for the following: username and password entered are only letters and numbers & more than 3 and 6; passwords match.
		# Checked with regular expressions.
		usernameCheck = not(re.compile("^[a-zA-Z0-9]{3,15}$").match(enteredUsername_ID.text) == None)
		passwordCheck = not(re.compile("^[a-zA-Z0-9]{6,20}$").match(enteredPassword_ID.text) == None)
		passwordMatchCheck = enteredPassword_ID.text == reEnteredPassword_ID.text


		# Now we check the database if the username is taken or not.
		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		cursor.execute("""
			SELECT * FROM users WHERE username = (?)
		""", (enteredUsername_ID.text,))

		# For our check to pass, there should NOT be a username that matches.
		user = cursor.fetchall()
		userCheck = not bool(user)

		connection.commit()
		connection.close()


		if usernameCheck and passwordCheck and passwordMatchCheck and userCheck:

			# Add user information to database.
			connection = sqlite3.connect("mainApp.db")
			cursor = connection.cursor()

			cursor.execute("""
				INSERT INTO users VALUES(?,?,?)
			""", (enteredUsername_ID.text, enteredPassword_ID.text, 0)
			)

			connection.commit()
			connection.close()

			# Remove text from registration page.
			enteredUsername_ID.text = ""
			enteredPassword_ID.text = ""
			reEnteredPassword_ID.text = ""

			# Display dialog box to notify user of successful registration.
			self.dialog = MDDialog(
				title="Registration successful! Now you can log in to your account.",
				buttons = [
					MDFlatButton(
						text="Cancel",
						on_release = self.closeDialog
					)
				]
			)

			self.dialog.open()

		else:
			self.dialog = MDDialog(
				title="Entered information was wrong... enter information again.",
				buttons = [
					MDFlatButton(
						text="Cancel",
						on_release = self.closeDialog
					)
				]
			)

			self.dialog.open()


	def setAppProfile(self, username_ID):
		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		cursor.execute("""
			SELECT points FROM users WHERE username = (?)
		""", (username_ID.text,))

		points = cursor.fetchall()[0][0]

		connection.commit()
		connection.close()

		self.root.get_screen('pagesWindow').ids.profileUsername.text = username_ID.text
		self.root.get_screen('pagesWindow').ids.profilePoints.text = str(points)


	def checkLoginInfo(self, username_ID, password_ID):

		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		# Check if user was created by checking for that specific username and password.
		cursor.execute("""
			SELECT * FROM users WHERE username = (?) AND password = (?)
		""", (username_ID.text, password_ID.text))

		user = cursor.fetchall()
		checkForUser = bool(user)

		connection.commit()
		connection.close()

		if checkForUser:
			self.setAppProfile(username_ID)

		return checkForUser



	def displayUnsuccessfulLogin(self):
		self.dialog = MDDialog(
			title="Unsuccessful Login.",
			buttons = [
				MDFlatButton(
					text="Cancel",
					on_release = self.closeDialog
				)
			]
		)

		self.dialog.open()


	#This code contains the hyperlinks to the news articles
	def link1(instance):
		webbrowser.open('https://en.wikipedia.org/wiki/Recycling')
		
	def link2(instance):
		webbrowser.open('https://en.wikipedia.org/wiki/Waste_management')
		
	def link3(instance):
		webbrowser.open('https://www.undp.org')

	def link4(instance):
		webbrowser.open('https://www.youtube.com/watch?v=iFcPqXxAUWM')
		
	def link5(instance):
		webbrowser.open('https://www.youtube.com/watch?v=3X1z188hedw')

	def link6(instance):
		webbrowser.open('https://www.youtube.com/watch?v=fFAjEsW71TU')
		
	def link7(instance):
		webbrowser.open('https://www.reddit.com/r/recycling')

	def link8(instance):
		webbrowser.open('https://en.wikipedia.org/wiki/Electronic_waste')  


	def redeemPoints(self, username_ID, points_ID):
		
		intPoints = int(points_ID.text)

		# Redeeming removes all points.
		intPoints = 0

		# Update the database.
		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		cursor.execute("""
			UPDATE users SET points = (?) WHERE username = (?)
		""", (intPoints, username_ID.text))

		connection.commit()
		connection.close()

		# Update the Profile Information
		self.root.get_screen('pagesWindow').ids.profileUsername.text = username_ID.text
		self.root.get_screen('pagesWindow').ids.profilePoints.text = str(intPoints)


		# Notify the user.
		self.dialog = MDDialog(
			title="You have successfully redeemed your points!",
			buttons = [
				MDFlatButton(
					text="Cancel",
					on_release = self.closeDialog
				)
			]
		)

		self.dialog.open()



	#This function displays a dialog, notifying the user of his successful recycle.
	def userRecycle(self, userName_ID, points_ID):

		intPoints = int(points_ID.text)

		# Recycling adds 100 points.
		intPoints = intPoints + 100

		# Update the database.
		connection = sqlite3.connect("mainApp.db")
		cursor = connection.cursor()

		cursor.execute("""
			UPDATE users SET points = (?) WHERE username = (?)
		""", (intPoints, userName_ID.text))

		connection.commit()
		connection.close()

		# Update the Profile Information
		self.root.get_screen('pagesWindow').ids.profileUsername.text = userName_ID.text
		self.root.get_screen('pagesWindow').ids.profilePoints.text = str(intPoints)


		# Notify the user.
		self.dialog = MDDialog(
			title="You have successfully recycled... 100 points have been added to your account!",
			buttons = [
				MDFlatButton(
					text="Cancel",
					on_release = self.closeDialog
				)
			]
		)

		self.dialog.open()


	def closeDialog(self, obj):
		self.dialog.dismiss()
		
		


MainApp().run()